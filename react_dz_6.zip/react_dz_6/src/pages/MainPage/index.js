// import MainPage from "./MainPage";


// export default MainPage;


export { default as MainPage } from './MainPage.js'